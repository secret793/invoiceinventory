<?php

namespace App\Filament\Resources\DeviceRetrievalResource\Pages;

use App\Filament\Resources\DeviceRetrievalResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDeviceRetrieval extends CreateRecord
{
    protected static string $resource = DeviceRetrievalResource::class;
}
