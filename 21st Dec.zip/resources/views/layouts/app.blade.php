<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laravel with Tailwind</title>
    @vite('resources/css/app.css')
</head>
<body>
    <div class="font-sans text-gray-900">
        {{ $slot }}
    </div>
    @vite('resources/js/app.js')
</body>
</html>
